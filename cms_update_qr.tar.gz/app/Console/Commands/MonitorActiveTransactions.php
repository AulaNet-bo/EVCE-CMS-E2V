<?php

namespace App\Console\Commands;

use App\Models\RfidTag;
use App\Models\Station;
use App\Models\Tariff;
use App\Models\User;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use App\Models\ChargingSession;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use GuzzleHttp\Cookie\CookieJar;
use App\Services\SteveDataSource;
use App\Services\BillingService;
use App\Services\SteveService;

class MonitorActiveTransactions extends Command
{
    protected $signature = 'steve:monitor-transactions {--daemon}';
    protected $description = 'Monitors active transactions in Steve, calculates cost, and enforces credit limits';

    public function handle(SteveDataSource $source, BillingService $billing, SteveService $steve)
    {
        $isDaemon = $this->option('daemon');

        do {
            $this->info("🔍 Scanning ALL transactions (Active & Recently Completed) in Steve ({$source->source()})...");

            try {
                $recentTxs = collect($source->getTransactionsForMonitoring(20));

                foreach ($recentTxs as $tx) {
                    $this->processTransaction($tx, $source, $billing, $steve);
                }

            } catch (\Exception $e) {
                $this->error("🔥 Monitor Failed: " . $e->getMessage());
                Log::error("Monitor Failed", ['error' => $e]);
            }

            if ($isDaemon) {
                sleep(5);
            }
        } while ($isDaemon);
    }

    private function processTransaction($tx, SteveDataSource $source, BillingService $billing, SteveService $steve)
    {
        $txId = $tx->transaction_pk ?? $tx->id;
        $tagCode = $tx->id_tag ?? null;
        $startTimestamp = $tx->start_timestamp ?? null;
        $stopTimestamp = $tx->stop_timestamp ?? null;
        $stopValue = $tx->stop_value ?? null;
        $stopReason = $tx->stop_reason ?? null;

        $existingSession = ChargingSession::where('transaction_id', $txId)->first();
        if ($existingSession && $existingSession->status === 'Completed') {
            $this->line("↪️  Tx #{$txId} already completed in CMS.");
            return;
        }

        $this->line("👉 Analyzing Tx #{$txId} (Tag: {$tagCode})");

        // 1. Identify User & Wallet
        $tag = RfidTag::where('tag_code', $tagCode)->first();
        $userId = $tag?->user_id;

        // 2. Determine Consumption (kWh)
        $isCompleted = !is_null($stopTimestamp);
        if ($isCompleted) {
            $currentWh = floatval($stopValue);
        } else {
            $lastEnergyMeter = $source->getLatestEnergyMeterValue((int) $txId);
            $currentWh = $lastEnergyMeter ? floatval($lastEnergyMeter->value) : 0;
        }

        $startWh = floatval($tx->start_value ?? 0);
        $consumedKwh = max(0, ($currentWh - $startWh) / 1000);

        // 3. Resolve Station and Connector
        $connector = $source->getConnectorByPk((int) ($tx->connector_pk ?? 0));
        $chargeBoxId = $connector->charge_box_id ?? 'Unknown';
        $station = Station::where('charge_box_id', $chargeBoxId)->first();
        
        // 4. Resolve Applicable Tariff
        $tariff = Tariff::resolveForStation($station, $startTimestamp);

        // 5. Update/Create ChargingSession in CMS
        if (!$existingSession) {
            // Adoption logic for 'Starting' sessions
            $existingSession = ChargingSession::where('status', 'Starting')
                ->where('station_id', $station->id ?? 0)
                ->where('rfid_tag_id', $tag?->id)
                ->orderByDesc('created_at')
                ->first();
        }

        $session = ChargingSession::updateOrCreate(
            ['id' => $existingSession?->id ?? 0],
            [
                'transaction_id' => (string)$txId,
                'station_id' => $station->id ?? 1,
                'user_id' => $userId,
                'rfid_tag_id' => $tag?->id,
                'tariff_id' => $tariff?->id,
                'total_energy_kwh' => $consumedKwh,
                'start_time' => $startTimestamp,
                'stop_time' => $stopTimestamp,
                'meter_start' => $startWh,
                'meter_stop' => $currentWh,
                'status' => $isCompleted ? 'Completed' : 'Active',
            ]
        );

        // 5. Initial Fee Processing (If not debited yet)
        if ($session->wasRecentlyCreated || (float)$session->debited_amount == 0) {
            $billing->processInitialFee($session);
        }

        // 6. Calculate Cost and Billing
        $pricing = $billing->calculateSessionCost($session, $consumedKwh, $isCompleted ? \Carbon\Carbon::parse($stopTimestamp) : null);

        if (!$isCompleted) {
            $ok = $billing->processIncrementalDebit($session, $pricing);
            if (!$ok) {
                $this->error("   🛑 INSUFFICIENT FUNDS! Sending RemoteStop...");
                $steve->remoteStop($chargeBoxId, (int)$txId);
                $session->update(['status' => 'CreditStopped', 'stop_reason' => 'CreditLimitExceeded']);
            }
        } else {
            $billing->finalizeBilling($session);
        }

        $this->line("   ✅ Synced Tx #{$txId}: " . ($isCompleted ? "Completed" : "Active") . " | {$consumedKwh} kWh | \${$pricing['total']}");
    }

}
