<?php

namespace App\Http\Controllers\Api\V1\Mobile;

use App\Http\Controllers\Controller;
use App\Models\SystemSetting;
use Illuminate\Http\Request;

class SystemController extends Controller
{
    public function config()
    {
        $settings = SystemSetting::get();

        return response()->json([
            'status' => 'success',
            'data' => [
                'platform_name' => $settings->platform_name,
                'branding' => [
                    'primary_color' => $settings->primary_color,
                    'secondary_color' => $settings->secondary_color,
                    'button_color' => $settings->button_color,
                    'text_color' => $settings->text_color,
                    'font_family' => $settings->font_family,
                ],
                'legal' => [
                    'disclaimer_url' => url('/disclaimer'),
                    'is_disclaimer_visible' => (bool) $settings->is_disclaimer_visible,
                ]
            ]
        ]);
    }
}
