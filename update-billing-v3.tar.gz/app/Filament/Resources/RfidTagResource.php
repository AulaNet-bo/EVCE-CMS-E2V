<?php

namespace App\Filament\Resources;

use App\Filament\Resources\RfidTagResource\Pages;
use App\Filament\Resources\RfidTagResource\Pages\BulkRfidManager;
use App\Filament\Resources\RfidTagResource\RelationManagers;
use App\Models\RfidTag;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Filament\Notifications\Notification;
use App\Models\WalletTransaction;
use App\Models\Wallet;

class RfidTagResource extends Resource
{
    protected static ?string $model = RfidTag::class;

    protected static ?string $navigationIcon = 'heroicon-o-identification';

    protected static ?string $navigationGroup = 'Operaciones';
    protected static ?string $modelLabel = 'Tarjeta RFID';
    protected static ?string $pluralModelLabel = 'Tarjetas RFID';

    public static function canCreate(): bool
    {
        return false;
    }

    public static function getEloquentQuery(): Builder
    {
        $query = parent::getEloquentQuery();
        $user = auth()->user();

        if ($user && $user->hasRole('enterprise_admin')) {
            return $query->where('company_id', $user->company_id);
        }

        return $query;
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('tag_code')
                    ->label('RFID Tag Code (8 chars)')
                    ->required()
                    ->maxLength(8)
                    ->helperText('Standard 4-byte UID hex (8 characters).')
                    // Auto-clean colons and non-alphanumeric chars on blur
                    ->afterStateUpdated(fn ($state, $set) => $set('tag_code', substr(strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $state)), -8)))
                    ->live(onBlur: true),
                Forms\Components\Select::make('user_id')
                    ->relationship('user', 'name')
                    ->default(null),
                Forms\Components\Select::make('company_id')
                    ->relationship('company', 'name')
                    ->default(null),
                Forms\Components\TextInput::make('name')
                    ->maxLength(255)
                    ->disabled(fn ($record) => $record?->is_virtual)
                    ->default(null),
                Forms\Components\Select::make('product_id')
                    ->label('Producto')
                    ->relationship('product', 'name')
                    ->required()
                    ->searchable()
                    ->preload(),
                Forms\Components\Toggle::make('is_active')
                    ->required(),
                Forms\Components\DatePicker::make('expires_at'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('tag_code')
                    ->searchable(),
                Tables\Columns\TextColumn::make('user.name')
                    ->numeric()
                    ->sortable(),
                Tables\Columns\TextColumn::make('company.name')
                    ->numeric()
                    ->sortable(),
                Tables\Columns\TextColumn::make('name')
                    ->searchable(),
                Tables\Columns\TextColumn::make('product.name')
                    ->label('Producto')
                    ->sortable(),
                Tables\Columns\TextColumn::make('balance')
                    ->label('Saldo (BOB)')
                    ->money('BOB')
                    ->sortable(),
                Tables\Columns\IconColumn::make('is_active')
                    ->label('Activa')
                    ->boolean(),
                Tables\Columns\TextColumn::make('is_virtual')
                    ->label('Tipo')
                    ->badge()
                    ->formatStateUsing(fn ($state) => $state ? 'Virtual' : 'Física')
                    ->color(fn ($state) => $state ? 'info' : 'gray'),
                Tables\Columns\TextColumn::make('expires_at')
                    ->date()
                    ->sortable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\Action::make('manual_recharge')
                    ->label('Recarga Manual')
                    ->icon('heroicon-o-currency-dollar')
                    ->color('warning')
                    ->form([
                        Forms\Components\TextInput::make('amount')
                            ->label('Monto a Recargar')
                            ->numeric()
                            ->required()
                            ->minValue(0.01)
                            ->default(10),
                        Forms\Components\TextInput::make('description')
                            ->label('Motivo / Descripción')
                            ->required()
                            ->maxLength(255)
                            ->default('Recarga de tarjeta RFID'),
                        Forms\Components\Toggle::make('emit_invoice')
                            ->label('Emitir Factura Oficial (Libélula)')
                            ->default(false)
                            ->helperText('Requiere que la tarjeta esté asignada a un usuario con datos de facturación.')
                            ->live(),
                    ])
                    ->action(function (RfidTag $record, array $data): void {
                        $amount = round((float) $data['amount'], 2);
                        
                        if ($data['emit_invoice'] && !$record->user_id) {
                            Notification::make()
                                ->title('Error de Facturación')
                                ->body('No se puede emitir factura si la tarjeta no está asignada a un usuario.')
                                ->danger()
                                ->send();
                            return;
                        }

                        DB::transaction(function () use ($record, $amount, $data) {
                            // 1. Update Tag balance (only for physical tags, virtual tags use wallet balance automatically)
                            if (!$record->is_virtual) {
                                $record->increment('balance', $amount);
                            } else {
                                // For virtual tags, we must ensure a wallet exists and increment it
                                $wallet = Wallet::firstOrCreate(
                                    ['user_id' => $record->user_id],
                                    ['currency' => 'BOB', 'balance' => 0]
                                );
                                $wallet->increment('balance', $amount);
                            }

                            // 2. Create Transaction Record for history and invoicing
                            $user = $record->user;
                            if ($user) {
                                $wallet = $user->wallet ?: $user->wallet()->create(['currency' => 'BOB', 'balance' => 0]);
                                $refCol = Schema::hasColumn('wallet_transactions', 'reference_id') ? 'reference_id' : 'reference';

                                $tx = WalletTransaction::create([
                                    'wallet_id' => $wallet->id,
                                    'user_id' => $user->id,
                                    'type' => 'RECHARGE',
                                    'amount' => $amount,
                                    'balance_after' => $record->is_virtual ? $wallet->balance : $record->balance,
                                    'currency' => $wallet->currency ?? 'BOB',
                                    $refCol => 'TAG-RECH-' . $record->tag_code . '-' . now()->timestamp,
                                    'description' => $data['description'],
                                    'status' => 'COMPLETED',
                                    'metadata' => [
                                        'rfid_tag' => $record->tag_code,
                                        'skip_wallet_update' => !$record->is_virtual, // Only skip if physical (balance already incremented)
                                    ],
                                ]);

                                // 3. Handle Invoicing if requested
                                if ($data['emit_invoice']) {
                                    $service = app(\App\Services\LibelulaPaymentService::class);
                                    $result = $service->createPayment($wallet, $amount, $data['description'], [
                                        'emite_factura' => true,
                                        'internal_usage_tx' => true, // Use the TX we just created
                                        'transaction_id' => $tx->id,
                                    ], true); // isPaid = true

                                    if ($result['success']) {
                                        Notification::make()
                                            ->title('Recarga y Factura procesada')
                                            ->success()
                                            ->send();
                                    } else {
                                        Notification::make()
                                            ->title('Recarga procesada, pero falló la factura')
                                            ->body($result['message'] ?? 'Error en Libélula')
                                            ->warning()
                                            ->send();
                                    }
                                } else {
                                    Notification::make()
                                        ->title('Recarga exitosa')
                                        ->success()
                                        ->send();
                                }
                            } else {
                                Notification::make()
                                    ->title('Recarga exitosa (Sin usuario)')
                                    ->success()
                                    ->send();
                            }
                        });
                    }),
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListRfidTags::route('/'),
            'bulk' => BulkRfidManager::route('/bulk'),
            'edit' => Pages\EditRfidTag::route('/{record}/edit'),
        ];
    }
}
