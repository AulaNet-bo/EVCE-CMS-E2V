<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;

class SteveDataSource
{
    protected static $localCache = [];

    protected function redis()
    {
        $conn = Redis::connection('default');
        $client = $conn->client();

        if ($client instanceof \Redis) {
            $client->setOption(\Redis::OPT_PREFIX, '');
        }

        return $conn;
    }

    protected function normalizeRedisRow(array $row): array
    {
        foreach ($row as $k => $v) {
            if ($v === '') {
                $row[$k] = null;
            }
        }

        return $row;
    }

    public function source(): string
    {
        // FORCED FIX: Overriding config to resolve production sync issues with stale Redis
        return 'mysql';
        
        /* Original logic:
        if (config('steve.force_redis_reads', true)) {
            return 'redis';
        }

        return config('steve.data_source', 'redis');
        */
    }

    public function usingRedis(): bool
    {
        return $this->source() === 'redis';
    }

    public function redisPrefix(): string
    {
        return config('steve.redis_prefix', 'steve');
    }

    public function getConnectorsWithStatus(): array
    {
        if (!$this->usingRedis()) {
            $baseItems = DB::connection('steve')
                ->table('connector')
                ->join('charge_box', 'connector.charge_box_id', '=', 'charge_box.charge_box_id')
                ->select(
                    'charge_box.charge_box_id',
                    'connector.connector_id',
                    'charge_box.last_heartbeat_timestamp',
                    'connector.connector_pk'
                )
                ->get()
                ->all();

            $pks = array_map(fn($row) => (int) $row->connector_pk, $baseItems);
            $statuses = $this->getMultipleConnectorStatuses($pks);

            foreach ($baseItems as $row) {
                $row->status = $statuses[$row->connector_pk] ?? 'Unknown';
            }

            return $baseItems;
        }

        $prefix = $this->redisPrefix();
        $keys = $this->redis()->smembers("{$prefix}:index:connectors");
        $connectors = [];

        // Fetch all connector hashes in one batch
        $rawConnectors = $this->redis()->pipeline(function ($pipe) use ($keys) {
            foreach ($keys as $key) {
                $pipe->hgetall($key);
            }
        });

        $rows = [];
        $connectorPks = [];
        $chargeBoxIds = [];

        foreach ($rawConnectors as $raw) {
            $connector = $this->normalizeRedisRow($raw ?? []);
            if (!$connector)
                continue;

            $rows[] = $connector;
            $connectorPks[] = (int) ($connector['connector_pk'] ?? 0);
            if ($cbid = $connector['charge_box_id'] ?? null) {
                $chargeBoxIds[$cbid] = true;
            }
        }

        // Fetch all charge boxes and statuses in batches
        $chargeBoxIds = array_keys($chargeBoxIds);
        $rawChargeBoxes = $this->redis()->pipeline(function ($pipe) use ($prefix, $chargeBoxIds) {
            foreach ($chargeBoxIds as $cbid) {
                $pipe->hgetall("{$prefix}:charge_box:{$cbid}");
            }
        });
        $chargeBoxes = [];
        foreach ($chargeBoxIds as $idx => $cbid) {
            $chargeBoxes[$cbid] = $this->normalizeRedisRow($rawChargeBoxes[$idx] ?? []);
        }

        $statuses = $this->getMultipleConnectorStatuses($connectorPks);

        $final = [];
        foreach ($rows as $connector) {
            $cbid = $connector['charge_box_id'] ?? null;
            $connectorPk = (int) ($connector['connector_pk'] ?? 0);
            $chargeBox = $chargeBoxes[$cbid] ?? [];

            $final[] = (object) [
                'charge_box_id' => $cbid,
                'connector_id' => (int) ($connector['connector_id'] ?? 0),
                'last_heartbeat_timestamp' => $chargeBox['last_heartbeat_timestamp'] ?? null,
                'connector_pk' => $connectorPk,
                'status' => $statuses[$connectorPk] ?? 'Unknown',
            ];
        }

        return $final;
    }

    public function getMultipleConnectorStatuses(array $connectorPks): array
    {
        $results = [];
        $toFetch = [];

        foreach ($connectorPks as $pk) {
            $cacheKey = "status:{$pk}";
            if (isset(static::$localCache[$cacheKey])) {
                $results[$pk] = static::$localCache[$cacheKey];
            } else {
                $toFetch[] = $pk;
            }
        }

        if (empty($toFetch)) {
            return $results;
        }

        if (!$this->usingRedis()) {
            $rows = DB::connection('steve')->table('connector_status')
                ->whereIn('connector_pk', $toFetch)
                ->whereRaw('status_timestamp = (SELECT MAX(status_timestamp) FROM connector_status as cs2 WHERE cs2.connector_pk = connector_status.connector_pk)')
                ->get();

            foreach ($rows as $row) {
                $status = $row->status ?? 'Unknown';
                $results[$row->connector_pk] = $status;
                static::$localCache["status:{$row->connector_pk}"] = $status;
            }
        } else {
            $prefix = $this->redisPrefix();
            $redis = $this->redis();

            // Use pipeline for O(1) round-trip
            $responses = $redis->pipeline(function ($pipe) use ($prefix, $toFetch) {
                foreach ($toFetch as $pk) {
                    $pipe->hgetall("{$prefix}:connector_status:{$pk}");
                }
            });

            foreach ($toFetch as $idx => $pk) {
                $row = $this->normalizeRedisRow($responses[$idx] ?? []);
                $status = $row['status'] ?? 'Available';
                $results[$pk] = $status;
                static::$localCache["status:{$pk}"] = $status;
            }
        }

        return $results;
    }

    public function getLatestChargeBoxStatus(string $chargeBoxId): ?string
    {
        $cacheKey = "cb_heartbeat:{$chargeBoxId}";
        if (isset(static::$localCache[$cacheKey])) {
            return static::$localCache[$cacheKey];
        }

        if (!$this->usingRedis()) {
            $row = DB::connection('steve')->table('charge_box')
                ->where('charge_box_id', $chargeBoxId)
                ->first();
            $heartbeat = $row->last_heartbeat_timestamp ?? null;
        } else {
            $prefix = $this->redisPrefix();
            $row = $this->normalizeRedisRow($this->redis()->hgetall("{$prefix}:charge_box:{$chargeBoxId}"));
            $heartbeat = $row['last_heartbeat_timestamp'] ?? null;
        }

        static::$localCache[$cacheKey] = $heartbeat;
        return $heartbeat;
    }

    public function getLatestConnectorStatus(int $connectorPk): ?string
    {
        $cacheKey = "status:{$connectorPk}";
        if (isset(static::$localCache[$cacheKey])) {
            return static::$localCache[$cacheKey];
        }

        if (!$this->usingRedis()) {
            $row = DB::connection('steve')->table('connector_status')
                ->where('connector_pk', $connectorPk)
                ->orderBy('status_timestamp', 'desc')
                ->first();
            $status = $row->status ?? null;
        } else {
            $prefix = $this->redisPrefix();
            $row = $this->normalizeRedisRow($this->redis()->hgetall("{$prefix}:connector_status:{$connectorPk}"));
            $status = $row['status'] ?? null;
        }

        static::$localCache[$cacheKey] = $status;
        return $status;
    }

    protected function enrichTransaction(array $row): array
    {
        $tx = (int) ($row['transaction_pk'] ?? 0);
        if ($tx <= 0) {
            return $row;
        }

        if (!empty($row['stop_timestamp']) && !empty($row['stop_value'])) {
            return $row;
        }

        $prefix = $this->redisPrefix();
        $stop = $this->normalizeRedisRow($this->redis()->hgetall("{$prefix}:transaction_stop:{$tx}"));
        if (!$stop) {
            return $row;
        }

        $row['stop_timestamp'] = $row['stop_timestamp'] ?? ($stop['stop_timestamp'] ?? null);
        $row['stop_value'] = $row['stop_value'] ?? ($stop['stop_value'] ?? null);
        $row['stop_reason'] = $row['stop_reason'] ?? ($stop['stop_reason'] ?? null);
        $row['stop_event_timestamp'] = $row['stop_event_timestamp'] ?? ($stop['event_timestamp'] ?? null);

        return $row;
    }

    public function getRecentTransactions(int $limit = 20): array
    {
        if (!$this->usingRedis()) {
            return DB::connection('steve')->table('transaction')
                ->orderBy('transaction_pk', 'desc')
                ->limit($limit)
                ->get()
                ->all();
        }

        $prefix = $this->redisPrefix();
        $keys = $this->redis()->smembers("{$prefix}:index:transactions");

        $rawRows = $this->redis()->pipeline(function ($pipe) use ($keys) {
            foreach ($keys as $key) {
                $pipe->hgetall($key);
            }
        });

        $rows = [];
        foreach ($rawRows as $raw) {
            $data = $this->normalizeRedisRow($raw ?? []);
            if (!$data) {
                continue;
            }
            $rows[] = (object) $this->enrichTransaction($data);
        }

        usort($rows, fn($a, $b) => ((int) ($b->transaction_pk ?? 0)) <=> ((int) ($a->transaction_pk ?? 0)));
        return array_slice($rows, 0, $limit);
    }

    public function getTransactionsForMonitoring(int $recentLimit = 20): array
    {
        if (!$this->usingRedis()) {
            $all = $this->getRecentTransactions(1000);

            $active = [];
            $completed = [];
            foreach ($all as $tx) {
                if (empty($tx->stop_timestamp)) {
                    $active[] = $tx;
                } else {
                    $completed[] = $tx;
                }
            }

            usort($completed, fn($a, $b) => ((int) ($b->transaction_pk ?? 0)) <=> ((int) ($a->transaction_pk ?? 0)));
            $completed = array_slice($completed, 0, $recentLimit);
            $merged = array_merge($active, $completed);
            usort($merged, fn($a, $b) => ((int) ($b->transaction_pk ?? 0)) <=> ((int) ($a->transaction_pk ?? 0)));
            return $merged;
        }

        $prefix = $this->redisPrefix();

        // Active = started but not stopped
        $startKeys = $this->redis()->smembers("{$prefix}:index:transaction_start");
        $stopKeys = $this->redis()->smembers("{$prefix}:index:transaction_stop");

        $allRaw = $this->redis()->pipeline(function ($pipe) use ($startKeys, $stopKeys) {
            foreach ($startKeys as $k)
                $pipe->hgetall($k);
            foreach ($stopKeys as $k)
                $pipe->hgetall($k);
        });

        $startCount = count($startKeys);
        $started = [];
        for ($i = 0; $i < $startCount; $i++) {
            $row = $this->normalizeRedisRow($allRaw[$i] ?? []);
            $tx = (int) ($row['transaction_pk'] ?? 0);
            if ($tx > 0)
                $started[$tx] = $row;
        }

        $stopped = [];
        for ($i = $startCount; $i < count($allRaw); $i++) {
            $row = $this->normalizeRedisRow($allRaw[$i] ?? []);
            $tx = (int) ($row['transaction_pk'] ?? 0);
            if ($tx > 0)
                $stopped[$tx] = true;
        }

        $activeIds = [];
        foreach ($started as $tx => $_) {
            if (!isset($stopped[$tx])) {
                $activeIds[] = (int) $tx;
            }
        }

        $rows = [];
        foreach ($activeIds as $tx) {
            $txRow = $this->getTransactionById($tx);
            if ($txRow) {
                $rows[] = $txRow;
                continue;
            }

            // fallback from transaction_start key
            $start = $this->normalizeRedisRow($this->redis()->hgetall("{$prefix}:transaction_start:{$tx}"));
            if ($start) {
                $rows[] = (object) [
                    'transaction_pk' => $start['transaction_pk'] ?? $tx,
                    'connector_pk' => $start['connector_pk'] ?? null,
                    'id_tag' => $start['id_tag'] ?? null,
                    'start_timestamp' => $start['start_timestamp'] ?? null,
                    'start_value' => $start['start_value'] ?? 0,
                    'stop_timestamp' => null,
                    'stop_value' => null,
                    'stop_reason' => null,
                ];
            }
        }

        $completed = [];
        foreach ($this->getRecentTransactions(300) as $tx) {
            if (!empty($tx->stop_timestamp)) {
                $completed[] = $tx;
            }
        }
        usort($completed, fn($a, $b) => ((int) ($b->transaction_pk ?? 0)) <=> ((int) ($a->transaction_pk ?? 0)));
        $completed = array_slice($completed, 0, $recentLimit);

        $merged = array_merge($rows, $completed);
        usort($merged, fn($a, $b) => ((int) ($b->transaction_pk ?? 0)) <=> ((int) ($a->transaction_pk ?? 0)));
        return $merged;
    }

    public function getTransactionById(int $transactionPk): ?object
    {
        if (!$this->usingRedis()) {
            return DB::connection('steve')->table('transaction')->where('transaction_pk', $transactionPk)->first();
        }

        $prefix = $this->redisPrefix();
        $row = $this->normalizeRedisRow($this->redis()->hgetall("{$prefix}:transaction:{$transactionPk}"));
        return $row ? (object) $this->enrichTransaction($row) : null;
    }

    public function getConnectorByPk(int $connectorPk): ?object
    {
        if (!$this->usingRedis()) {
            return DB::connection('steve')->table('connector')->where('connector_pk', $connectorPk)->first();
        }

        $prefix = $this->redisPrefix();
        $row = $this->normalizeRedisRow($this->redis()->hgetall("{$prefix}:connector:{$connectorPk}"));
        return $row ? (object) $row : null;
    }

    public function getLatestMeterValue(int $transactionPk, ?string $measurand = null): ?object
    {
        $cacheKey = "meter:{$transactionPk}:" . ($measurand ?? 'all');
        if (isset(static::$localCache[$cacheKey])) {
            return static::$localCache[$cacheKey];
        }

        if (!$this->usingRedis()) {
            $q = DB::connection('steve')->table('connector_meter_value')->where('transaction_pk', $transactionPk);
            if ($measurand) {
                $q->where('measurand', $measurand);
            }
            $latest = $q->orderBy('value_timestamp', 'desc')->first();
        } else {
            $prefix = $this->redisPrefix();
            $txIdxKey = "{$prefix}:index:meter_values:tx:{$transactionPk}";

            // Try the new per-transaction index first
            $keys = $this->redis()->smembers($txIdxKey);

            // Fallback to global index if tx-specific is empty (legacy data)
            if (empty($keys)) {
                $keys = $this->redis()->smembers("{$prefix}:index:meter_values");
            }

            if (empty($keys)) {
                return null;
            }

            // Pipe hgetall for all candidate keys
            $rawRows = $this->redis()->pipeline(function ($pipe) use ($keys) {
                foreach ($keys as $key) {
                    $pipe->hgetall($key);
                }
            });

            $latestRow = null;
            foreach ($rawRows as $raw) {
                $row = $this->normalizeRedisRow($raw ?? []);
                if (!$row)
                    continue;

                // If we used the global index, we must filter by transaction_pk
                if ((int) ($row['transaction_pk'] ?? -1) !== $transactionPk)
                    continue;
                if ($measurand && ($row['measurand'] ?? null) !== $measurand)
                    continue;

                if (!$latestRow || (($row['value_timestamp'] ?? '') > ($latestRow['value_timestamp'] ?? ''))) {
                    $latestRow = $row;
                }
            }
            $latest = $latestRow ? (object) $latestRow : null;
        }

        static::$localCache[$cacheKey] = $latest;
        return $latest;
    }

    public function getLatestEnergyMeterValue(int $transactionPk): ?object
    {
        // Primary measurand used by simulator and most OCPP stacks
        $mv = $this->getLatestMeterValue($transactionPk, 'Energy.Active.Import.Register');
        if ($mv) {
            return $mv;
        }

        // Secondary common variant
        $mv = $this->getLatestMeterValue($transactionPk, 'Energy.Active.Import');
        if ($mv) {
            return $mv;
        }

        // Fallback: any energy measurand
        if (!$this->usingRedis()) {
            return DB::connection('steve')->table('connector_meter_value')
                ->where('transaction_pk', $transactionPk)
                ->where('measurand', 'like', 'Energy%') // More broad match
                ->orderBy('value_timestamp', 'desc')
                ->first();
        }

        $prefix = $this->redisPrefix();
        $keys = $this->redis()->smembers("{$prefix}:index:meter_values");
        $latest = null;
        foreach ($keys as $key) {
            $row = $this->normalizeRedisRow($this->redis()->hgetall($key));
            if (!$row) {
                continue;
            }
            if ((int) ($row['transaction_pk'] ?? -1) !== $transactionPk) {
                continue;
            }
            $m = (string) ($row['measurand'] ?? '');
            // Broad search for anything containing "Energy"
            if (stripos($m, 'Energy') === false) {
                continue;
            }
            if (!$latest || (($row['value_timestamp'] ?? '') > ($latest['value_timestamp'] ?? ''))) {
                $latest = $row;
            }
        }

        return $latest ? (object) $latest : null;
    }

    public function getTagsForSync(int $limit = 500): array
    {
        if (!$this->usingRedis()) {
            return DB::connection('steve')->table('ocpp_tag')
                ->orderBy('ocpp_tag_pk', 'desc')
                ->limit($limit)
                ->get()
                ->map(fn($r) => (array) $r)
                ->all();
        }

        $prefix = $this->redisPrefix();
        $keys = $this->redis()->smembers("{$prefix}:index:tags");
        $rows = [];
        foreach ($keys as $key) {
            $row = $this->normalizeRedisRow($this->redis()->hgetall($key));
            if (!$row) {
                continue;
            }
            $rows[] = $row;
        }

        usort($rows, fn($a, $b) => strcmp((string) ($b['id_tag'] ?? ''), (string) ($a['id_tag'] ?? '')));
        return array_slice($rows, 0, $limit);
    }

    public function getSessionsForSync(?string $since = null, ?int $afterTransactionPk = null, int $limit = 200): array
    {
        if (!$this->usingRedis()) {
            $query = DB::connection('steve')->table('transaction');

            if ($since) {
                $query->where('start_timestamp', '>=', $since);
            } elseif ($afterTransactionPk) {
                $query->where('transaction_pk', '>', $afterTransactionPk);
            }

            return $query->orderBy('transaction_pk', 'asc')->limit($limit)->get()->all();
        }

        $prefix = $this->redisPrefix();
        $keys = $this->redis()->smembers("{$prefix}:index:transactions");
        $rows = [];

        foreach ($keys as $key) {
            $row = $this->normalizeRedisRow($this->redis()->hgetall($key));
            if (!$row) {
                continue;
            }

            $tx = (int) ($row['transaction_pk'] ?? 0);
            if ($afterTransactionPk && $tx <= $afterTransactionPk) {
                continue;
            }

            if ($since && !empty($row['start_timestamp']) && $row['start_timestamp'] < $since) {
                continue;
            }

            $rows[] = (object) $this->enrichTransaction($row);
        }

        usort($rows, fn($a, $b) => ((int) ($a->transaction_pk ?? 0)) <=> ((int) ($b->transaction_pk ?? 0)));
        return array_slice($rows, 0, $limit);
    }
}
