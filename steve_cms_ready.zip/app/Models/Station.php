<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Station extends Model
{
    use HasFactory;

    protected $fillable = [
        'charge_box_id',
        'location_id',
        'tariff_id',
        'name',
        'model',
        'vendor',
        'serial_number',
        'firmware_version',
        'last_ip',
        'last_heartbeat',
        'is_active',
    ];

    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class);
    }

    public function tariff(): BelongsTo
    {
        return $this->belongsTo(Tariff::class);
    }

    public function connectors(): HasMany
    {
        return $this->hasMany(Connector::class);
    }

    public function getLastHeartbeatAttribute($value)
    {
        return app(\App\Services\SteveDataSource::class)->getLatestChargeBoxStatus($this->charge_box_id) ?? $value;
    }

    public function getStatusAttribute()
    {
        $connectors = $this->connectors;
        if ($connectors->isEmpty()) {
            return 'Offline';
        }

        $statuses = $connectors->pluck('status')->unique();

        if ($statuses->contains('Charging')) {
            return 'Charging';
        }
        if ($statuses->contains('Occupied')) {
            return 'Occupied';
        }
        if ($statuses->contains('Available')) {
            return 'Available';
        }

        return $statuses->first() ?? 'Unknown';
    }
}
